const PATH = '../../backend/services';
const EmissionService = require(`${PATH}/emission-service`);
const TransferService = require(`${PATH}/transfer-service`);
const MirrorService = require(`${PATH}/mirror-service`);
const ReplayService = require(`${PATH}/replay-service`);
const ThresholdService = require(`${PATH}/threshold-service`);

class ExecutionGateway {
  async execute(intent) {
    if (!intent || !intent.action) {
      return { success: false, error: 'Некорректный intent: отсутствует action' };
    }

    try {
      switch (intent.action) {
        case 'plan':
          return await EmissionService.execute(intent.payload);
        case 'flow':
          return await TransferService.execute(intent.payload);
        case 'mirror':
          return await MirrorService.execute(intent.payload);
        case 'replay':
          return await ReplayService.execute(intent.payload);
        case 'threshold':
          return await ThresholdService.execute(intent.payload);
        default:
          return { success: false, error: `Неизвестный action: ${intent.action}` };
      }
    } catch (err) {
      return { success: false, error: err.message };
    }
  }
}

module.exports = ExecutionGateway;
