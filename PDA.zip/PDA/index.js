const IntentRouter = require('./core/intent-router');
const PreviewEngine = require('./core/preview-engine');
const ExecutionGateway = require('./core/execution-gateway');

const Canon = require('../backend/core/canon');
const Metronome = require('../backend/core/metronome');

const intentRouter = new IntentRouter();
const previewEngine = new PreviewEngine(Canon, Metronome);
const executionGateway = new ExecutionGateway();

class PDA {
  constructor() {
    this.Canon = Canon;
    this.Metronome = Metronome;
  }

  resolve(action, payload = {}) {
    const intent = intentRouter.resolve(action, payload);
    if (!intent.valid) return intent;
    return intent;
  }

  preview(intent) {
    return previewEngine.compute(intent);
  }

  async execute(intent) {
    const preview = this.preview(intent);
    if (preview.blocked) return { success: false, preview };
    return executionGateway.execute(intent);
  }

  async run(action, payload = {}) {
    const intent = this.resolve(action, payload);
    if (!intent.valid) return intent;
    const preview = this.preview(intent);
    return { intent, preview };
  }

  async confirm(action, payload = {}) {
    const intent = this.resolve(action, payload);
    if (!intent.valid) return intent;
    const preview = this.preview(intent);
    if (preview.blocked) return { success: false, preview };
    const result = await executionGateway.execute(intent);
    return { intent, preview, result };
  }

  getStatus() {
    return {
      version: require('./package.json').version,
      canon: this.Canon.CANON_VERSION,
      phase: this.Metronome.getCurrentPhase(),
      time: this.Metronome.getCurrentTimeISO(),
      emission_allowed: this.Metronome.isEmissionAllowed(),
      transfer_allowed: this.Metronome.isTransferAllowed(),
    };
  }
}

module.exports = { PDA, intentRouter, previewEngine, executionGateway };
